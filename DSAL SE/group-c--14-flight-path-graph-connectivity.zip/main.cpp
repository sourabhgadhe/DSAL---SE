/* There are flight paths between cities. If there is a flight between city A and city B then
there is an edge between the cities. The cost of the edge can be the time that flight take
to reach city B from A, or the amount of fuel used for the journey. Represent this as a
graph. The node can be represented by airport name or name of the city. Use adjacency
list representation of the graph or use adjacency matrix representation of the graph.
Check whether the graph is connected or not. Justify the storage representation used. */ 

#include<iostream>
using namespace std;

int nodes;
int adj_mat[20][20];
int visited[20];
string city[20];

void DFS(int i)   // function for DFS traversal
{
    cout<<city[i]<<" ";
    visited[i]=1;                   // marking current node as visited
    for (int j=0; j<nodes; j++)
    {
        if (adj_mat[i][j]==1 && visited[j]==0)
        {
            DFS(j);                    // recurrsive call for unvisited nodes
        }
    }
}

void is_Connected()          // function for checking graph connectivity
{ 
    for(int i=0;i<nodes;i++)
    {
        if(visited[i]==0)
        {
            cout<<"\nThe graph is Disconnected Graph !!";
            break;
        }
        
        else if(i==nodes-1 && visited[i]==1)
        {
            cout<<"\nThe graph is Connected Graph !!";
            break;
        }
    }
}

int main()
{
    
    cout<<"Enter the number of cities: ";   // taking user input for node (cities)
    cin>>nodes;
    
    cout<<"Enter the cities: "<<endl;
    for(int i=0; i<nodes; i++)
    {
        cout<<"City "<<i+1<<": ";
        cin>>city[i];
    }
    cout<<"\nEntered cities are...."<<endl;  // displaying entered cities
    
    for(int j=0; j<nodes; j++)
    {
        cout<<city[j]<<"  ";
    }
    
    for(int i=0; i<(nodes); i++)
    {
        for(int j=0; j<nodes; j++)
        {
            cout<<"\n\nIs there any route from "<<city[i]<<" to "<<city[j]<<" (Enter: 1/0) : ";
            cin>>adj_mat[i][j];    // creating Adjacency matrix
        }
    }
    
    cout<<"\nThe Adjacency matrix is :"<<endl<<"\n";  
    
    for(int a=0; a<nodes; a++)
    {
        for(int b=0; b<nodes; b++)
        {
            cout<<"("<<city[a]<<","<<city[b]<<") "<<adj_mat[a][b]<<" "; // displaying Adjacency matrix
        }
        cout<<endl;
    }
    
    int initial_node;
    cout<<endl;
    for (int a=0; a<nodes; a++)
    {
        cout<<"Node("<<a<<")"<<" : "<<city[a]<<endl; // displaying node values for each city
    }
    
    cout<<"\n\nFrom which node do you want to start DFS? (Enter integer value of a node -> 0,1...): ";
    cin>>initial_node;                              // asking for initial node for DFS traversal
    cout<<"\nDFS Traversal for given graph is: ";
    
    DFS(initial_node);                        // calling DFS function 
    
    is_Connected();                            //calling graph connectivity function 
    
    return 0;
}










