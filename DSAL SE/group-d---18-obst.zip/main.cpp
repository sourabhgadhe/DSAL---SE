/* Given sequence k = k1 <k2 < … <kn of n sorted keys, with a search probability pi for each
key ki . Build the Binary search tree that has the least search cost given the access probability for each key? */

#include <bits/stdc++.h>
using namespace std;

int sum(int freq[], int i, int j)    // A utility function to get sum of array elements freq[i] to freq[j]
{
    int s = 0;
    for (int r = i; r <= j; r++)
    s += freq[r];
    return s;
}
 
int optCost(int freq[], int i, int j)      // A recursive function to calculatecost of optimal binary search tree
{
    // Base cases
    if (i > j)             // no elements in this subarray
        return 0;
    if (j == i)             // one element in this subarray
        return freq[i];
     
    int fsum = sum(freq, i, j);      // Get sum of freq[i], freq[i+1], ... freq[j]
     
    int min = INT_MAX;               // Initialize minimum value
     
    
    for (int r = i; r <= j; r++)                // One by one consider all elements as root and recursively find cost of the BST, 
    {                                             // compare the cost with min and update min if needed
        int cost = optCost(freq, i, r - 1) + optCost(freq, r + 1, j);
        if (cost < min)
            min = cost;
    }
     
    return min + fsum;      // Return minimum value
}
 
int main()
{
int n;
cout<<"Enter the size of the array: ";
cin>>n;
int keys[n],freq[n];

cout<<"Enter the keys in sorted order (ascending order): \n";
for(int i=0;i<n;i++)
{
    cin>>keys[i];
}

cout<<"\nEnter their respective frequencies: \n";

for(int j=0;j<n;j++)
{
    cin>>freq[j];
}

cout<<"\nCost of Optimal BST is "<< optCost(freq, 0, n - 1);

return 0;
}





