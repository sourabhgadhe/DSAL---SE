/* A Dictionary stores keywords & its meanings. Provide facility for adding new keywords,
deleting keywords, updating values of any entry. Provide facility to display whole data
sorted in ascending/ Descending order. Also find how many maximum comparisons may
require for finding any keyword. Use Height balance tree and find the complexity for
finding a keyword */

#include <iostream>
#include<iomanip>
#include<string.h>
using namespace std;

class node{
 string key;
 string meaning;
 node *left,*right;
 int height;
public:
 node(){
  left=right=NULL;
  height=1;
  meaning="";
  key="";
}

 node(string key,string meaning)
 {
  this->key=key;
  this->meaning=meaning;
  left=right=NULL;
  height=1;
 }

 void print()
 {
  cout<<endl<<setw(10)<<key<<setw(10)<<meaning;
 }
 friend class Dictionary;
};


class Dictionary
{
 node *root,*temp;
 string k;
public:

 Dictionary()
{
  root=NULL;
}
 node* deleteNode(node* root, string key);
 void deleteInit(string key);
 int max(int,int);
 int getheight(node*);
 node *insert(node *rnode,string key,string meaning);
 void insertInit(string key,string meaning);
 node *rightRotate(node *);
 node *leftRotate(node *);
 int getbalance(node*);
 void preorder();
 void preorderRec(node*);
 void postorder();
 void postorderRec(node *);
 void inorder();
 void inorderRec(node *);
 node* minValueNode(node* n);
 void update(node* root);
 void upd();
 void search(node*);
 void sea();
 
};

void Dictionary::search(node * root){
    int flag=0;
    cout<<"Enter the key : "; 
    cin>>k;
    cout<<endl;
    temp=root;
    while(temp!=NULL){
        if(k==temp->key){
            cout<<"KEY FOUND\n";
            cout<<"\nMeaning is : "<<temp->meaning<<endl; 
            flag=1; 
            break; 
        } 
        node *parent=temp; 
        if(k>parent->key){
            temp=temp->right;
        }
        else{
            temp=temp->left;
        }
    }

if(flag==0){
    cout<<"KEY NOT FOUND"<<endl; 
    } 
}

void Dictionary :: sea(){
    search(root);
}

void Dictionary::update(node * root){
    int flag=0;
    cout<<"Enter the key whose meaning is to be updated : "; 
    cin>>k;
    cout<<endl;
    temp=root;
    while(temp!=NULL){
        if(k==temp->key){
            cout<<"Enter the new meaning : ";
            cin>>temp->meaning; 
            flag=1;
            cout<<"\nTHE MEANING IS UPDATED\n";
            break; 
        } 
        node *parent=temp; 
        if(k>parent->key){
            temp=temp->right;
        }
        else{
            temp=temp->left;
        }
    }
    if(flag!=1){
        cout<<"\nKey not found\n";
    }
}

void Dictionary :: upd(){
    update(root);
}

int Dictionary::max(int a,int b)
{
 return (a>b)?a:b;
}


int Dictionary::getheight(node *nnode)
{
 if(nnode==NULL)
  return 0;
 else
  return nnode->height;
}


int Dictionary::getbalance(node *n)
{
 if(n==NULL)
  return 0;
 else
  return (getheight(n->left)-getheight(n->right));
}

node* Dictionary::rightRotate(node *y)
{
 node *x=y->left;
 node *xr=x->right;

 //Update Pointers after rotation
 x->right=y;
 y->left=xr;

 y->height=max(getheight(y->left),getheight(y->right))+1;
 x->height=max(getheight(x->left),getheight(x->right))+1;
 return x;
}

node* Dictionary::leftRotate(node *y)
{
 node *x=y->right;
 node *t2=x->left;

 x->left=y;
 y->right=t2;

 y->height=max(getheight(y->left),getheight(y->right))+1;
 x->height=max(getheight(x->left),getheight(x->right))+1;

 return x;
}

node* Dictionary::insert(node *rnode,string key,string meaning)
{
 //1. Normat BST Operation
 if(rnode==NULL) //Empty Dictionary
  return new node(key,meaning);

 if(key<rnode->key){
  rnode->left=insert(rnode->left,key,meaning);
 }
 else if(key>rnode->key){
  rnode->right=insert(rnode->right,key,meaning);
 }
 else{ //equal value key
  return rnode;
 }

 //2. update height of ancestors
 rnode->height=1+max(getheight(rnode->left),getheight(rnode->right));

 //3. Get balancing factor
 int balance=getbalance(rnode);

 //4. perform rotations and return nre root
 //LL Case
 if(balance>1 && key<rnode->left->key)
  return rightRotate(rnode);

 //RR Case
 if(balance<-1 && key>rnode->right->key)
  return leftRotate(rnode);

 //LR Case
 if(balance>1 && key>rnode->left->key)
 {
  rnode->left=leftRotate(rnode->left);
  return rightRotate(rnode);
 }

 //RL Case
 if(balance<-1 && key<rnode->right->key)
 {
  rnode->right=rightRotate(rnode->right);
 return leftRotate(rnode);
 }

 return rnode; //no change in root

}


void Dictionary::preorder()
{
 preorderRec(root);
}


void Dictionary::postorder()
{
 postorderRec(root);
}


void Dictionary::inorder()
{
 inorderRec(root);
}


void Dictionary::preorderRec(node *n)
{
 if(n)
 {
  n->print();
  preorderRec(n->left);
  preorderRec(n->right);
 }
}

void Dictionary::inorderRec(node *n)
{
 if(n)
 {
  inorderRec(n->left);
  n->print();
  inorderRec(n->right);
 }
}

void Dictionary::postorderRec(node *n)
{
 if(n)
 {
  postorderRec(n->left);
  postorderRec(n->right);
  n->print();
 }
}
void Dictionary::insertInit(string key,string meaning)
{
 root=insert(root,key,meaning);
}

void Dictionary::deleteInit(string key)
{
 root=deleteNode(root,key);
}

node* Dictionary :: deleteNode(node* root, string key ) { 
      
    // STEP 1: PERFORM STANDARD BST DELETE 
    if (root == NULL){ 
        cout<<"\nKey not found \n";
        return root; 
    }
    // If the key to be deleted is smaller 
    // than the root's key, then it lies
    // in left subtree 
    if ( key < root->key ) 
        root->left = deleteNode(root->left, key); 
  
    // If the key to be deleted is greater 
    // than the root's key, then it lies 
    // in right subtree 
    else if( key > root->key ) 
        root->right = deleteNode(root->right, key); 
  
    // if key is same as root's key, then 
    // This is the node to be deleted 
    else
    { 
        // node with only one child or no child 
        if( (root->left == NULL) ||
            (root->right == NULL) ) 
        { 
            node *temp = root->left ? 
                         root->left : 
                         root->right; 
  
            // No child case 
            if (temp == NULL) 
            { 
                temp = root; 
                root = NULL; 
            } 
            else // One child case 
            *root = *temp; // Copy the contents of 
                           // the non-empty child 
            free(temp);

        } 
        else
        { 
            // node with two children: Get the inorder 
            // successor (smallest in the right subtree) 
            node* temp = minValueNode(root->right); 
  
            // Copy the inorder successor's 
            // data to this node 
            root->key = temp->key; 
  
            // Delete the inorder successor 
            root->right = deleteNode(root->right, 
                                     temp->key); 
        } 
    } 
  
    // If the tree had only one node
    // then return 
    if (root == NULL) 
    return root; 
  
    // STEP 2: UPDATE HEIGHT OF THE CURRENT NODE 
    root->height = 1 + max(getheight(root->left), 
                           getheight(root->right)); 
  
    // STEP 3: GET THE BALANCE FACTOR OF 
    // THIS NODE (to check whether this 
    // node became unbalanced) 
    int balance = getbalance(root); 
  
    // If this node becomes unbalanced, 
    // then there are 4 cases 
  
    // Left Left Case 
    if (balance > 1 && 
        getbalance(root->left) >= 0) 
        return rightRotate(root); 
  
    // Left Right Case 
    if (balance > 1 && 
        getbalance(root->left) < 0) 
    { 
        root->left = leftRotate(root->left); 
        return rightRotate(root); 
    } 
  
    // Right Right Case 
    if (balance < -1 && 
        getbalance(root->right) <= 0) 
        return leftRotate(root); 
  
    // Right Left Case 
    if (balance < -1 && 
        getbalance(root->right) > 0) 
    { 
        root->right = rightRotate(root->right); 
        return leftRotate(root); 
    } 
  
    return root; 
} 

node* Dictionary :: minValueNode(node* n) 
{ 
    node* current = n; 
  
    /* loop down to find the leftmost leaf */
    while (current->left != NULL) 
        current = current->left; 
  
    return current; 
} 

int main() {

 Dictionary d;
 
    int ch,n,num;
    string di,keyy,me;
    char ans;
    do{
        cout<<"\n**** MENU ****\n";
        cout<<"\n1) Insert new node \n2) Display using inorder traversal"; 
        cout<<"\n3) search for any value \n4) update the meaning of key \n5) delete any key \n6) Exit"<<endl;
        cout<<"Enter Your Choice : "; 
        cin>>ch;
        cout<<endl;
    switch(ch){
    case 1:
        cout<<"How many keys do you want to insert : ";
        cin>>num;
        for(int i=0;i<num;i++){
           cout<<"\nEnter the key "<<i+1<<" : ";
           cin>>keyy;
           cout<<"\nEnter the meaning of key "<<i+1<<" : ";
           cin>>me; 
           d.insertInit(keyy,me); 
        }
        break;
    case 2:
        cout<<"******INORDER*****\n";
        cout<<endl;
        d.inorder();
        cout<<endl;
        break;
    case 3:
        d.sea();
        break;
    case 4:
        d.upd();
        break;
    case 5:
        cout<<"\nEnter Keyword which u want to delete : ";
        cin>>di;
        d.deleteInit(di);
        break;
    case 6:
        cout<<"Thankyou"<<endl;
        break;      
    }
}while(ch<6);

 return 0;
}
