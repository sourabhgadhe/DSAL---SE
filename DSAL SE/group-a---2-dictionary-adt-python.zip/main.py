# Implement all the functions of a dictionary (ADT) using hashing and handle collisions using chaining with / without replacement.
# Data: Set of (key, value) pairs, Keys are mapped to values, Keys must be comparable, Keys must be unique
# Standard Operations: Insert(key, value), Find(key), Delete(key)

hashtable = [[]for _ in range(10)]


def insert(key,value):
    index = key % len(hashtable)
    hashtable[index].append(value)

def display():
    for i in range(len(hashtable)):
        print(i,end=" ")
        for j in hashtable[i]:
            print(" --> ",end=" ")
            print(j,end=" ")
        print()

def search(key,val):
    index = key % len(hashtable)
    for elem in hashtable[index]:
        if(elem==val):
            print("\nRecord Found !!")
            return
        
    print("\nRecord Not Found !!")

def delete(key,val):
    index = key % len(hashtable)
    for elem in hashtable[index]:
        if(elem==val):
            hashtable[index].remove(elem)
            print("\nRecord deletd successfully !!\n")
            return
    print("\nRecord to be deleted was not found !!\n")


insert(20,"Allahabad")
insert(10,"Mumbai")
insert(44,"Pune")
insert(27,"Satara")
display()

search(10,"Mumbai")
delete(44,"Pune")
display()
