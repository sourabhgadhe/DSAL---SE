/* Read the marks obtained by students of second year in an online examination of
particular subject. Find out maximum and minimum marks obtained in that subject. Use
heap data structure. Analyze the algorithm.*/

# include <bits/stdc++.h>
using namespace std;

void heapify(vector<int> &arr, int i, int n)  //heapify kis aaray me karn ahai uska size , kahan se karna HAI I 
{
    int largest = i;         //largest ko intialize kiya i se ,hence start point se 
    int l = 2*i + 1;        //left node ,exists at 2i+1 th index as we are starting from 0th index and right at 2i+2 th index
    int r = 2*i + 2;        //if index starts from 1 left child is 2i and right is 2i+1 //right exists at 2i+2 nd node 

    if(l<n && arr[l] > arr[largest])     //ahar left child , upar wale se bada hai toh update kar denge 
    {
        largest = l;
    }

    if(r<n && arr[r] > arr[largest])     //same goes for right too 
    {
        largest = r;
    }

    if(largest != i)     //upar wali iterattions khatam hone ke baad agar largest i ke baharbar nahi hai ,toh swap karenge
    {     
        swap(arr[i], arr[largest]);
        heapify(arr, largest, n);        //phir naye mile tree pe vapis heapify laga denge
    }

}

void heapSort(vector<int> &arr)
{
    int n = arr.size(); 
    for(int i=n/2-1; i>=0; i--)     // i=n/2-1 , last non-leaf node ka index de dega
    { 
        heapify(arr, i, n);     //waha pe heapify call kar dunga last element n se le kar 1st i tak ke liye , hence 1st node se
    }                           //aur n/2-1 -- hai toh uske further neeche  

    for(int i=n-1; i>=0; i--)        
    {                               // sare vec ke inexes me se
        swap(arr[0], arr[i]);       //swap kar do arr[0] and last wale 
        heapify(arr, 0, i);         //bache hue pe heapify call kar do
    }
}

int main(){
    int n;
    cout<<"Enter total no. of students: ";
    cin>>n;
    
    vector<int>arr(n);
    cout<<"\nEnter their marks: ";
    for(int i=0; i<n; i++)
    {
        cin>>arr[i];
    }
    
    heapSort(arr);

    cout<<"Sorted Marks: \n";
    for(int i=0; i<n; i++)
    {
        cout<<arr[i]<<" ";
    }

    cout<<"\nMinimum marks obtained : "<<arr[0];
	cout<<"\nMaximum marks obtained : "<<arr[n-1];

    return 0;
}








