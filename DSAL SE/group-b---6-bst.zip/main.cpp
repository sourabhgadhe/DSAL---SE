/* Beginning with an empty binary search tree, Construct binary search tree by inserting the values in the order given.
After constructing a binary tree -
i. Insert new node
ii. Find number of nodes in longest path from root
iii. Minimum data value found in the tree
iv. Change a tree so that the roles of the left and right pointers are swapped at every node
v. Search a value */

#include <bits/stdc++.h>
using namespace std;

struct node {
	int key;
	node *left, *right;
};

class Btree
{   
    int n;
    int x;
    
    public:
    node *root;
    Btree()
    {
        root=NULL;
    }
    
    node* newNode(int item)
    {
	    node* temp = new node();
	    temp->key = item;
	    temp->left = temp->right = NULL;
	    return temp;
    }
    
void create ()
{
  cout<<"\nEnter the number of nodes in BST : ";
  cin>>n;
  for(int i = 0 ; i < n ; i++)
  {
   cout<<"Enter the node to be inserted: ";
   cin>>x;
   root=insert(root , x);
  }
}
    
node* insert(node* temp, int key)
{
	if (temp == NULL)           
		temp= newNode(key);             /* If the tree is empty, return a new node */

	else if (key < temp->key)                   /* Otherwise, recur down the tree */
		temp->left = insert(temp->left, key);
		
	else
		temp->right = insert(temp->right, key);
		
	return temp;   // returns the leaf node
}
 
void search(node*temp,int key)
{
    while( temp != NULL)
    {
        if(temp->key == key)
        {
            cout<<"\nKey Found !!";
            break;
        }
   
        else if(key < temp->key)
        {
            temp=temp->left;
        }
    
        else 
        {
            temp=temp->right;
        }
   
    }
    if(temp==NULL)
    {
        cout<<"\nKey Not Found !!";
    }
}
 
 void minValueNode(node* temp)
{
	while(temp->left != NULL)
  {
      temp = temp->left;
  }
  
  cout<<"\nMinimum value in the Tree is: "<<temp->key<<endl;;
}

void mirror(node *temp)
{
  if(temp == NULL)
  {
   return;
  }
  else
  {
   node *ptr;
   mirror(temp->left);
   mirror(temp->right);
   ptr = temp->left;
   temp->left = temp->right;
   temp->right = ptr; 
  }
  
}
 
void display()
{
  cout<<endl<<"--- PREORDER TRAVERSAL ---"<<endl;
  preorder(root);
  cout<<endl;
  cout<<endl<<"--- INORDER TRAVERSAL ---"<<endl;
  inorder(root);
  cout<<endl;
  cout<<endl<<"--- POSTORDER TRAVERSAL ---"<<endl;
  postorder(root);
  cout<<endl;
  
  
}
 
void inorder(node *temp)
{
  if(temp != NULL)
  {
   inorder(temp->left);
   cout<<temp->key<<"  ";
   inorder(temp->right);
  }
} 

void postorder(node *temp)
 {
  if(temp != NULL)
  {
   postorder(temp->left);
   postorder(temp->right);
   cout<<temp->key<<" ";
  }
}
 
void preorder(node *temp)
{
  if(temp != NULL)
  {
   cout<<temp->key<<" ";
   preorder(temp->left);
   preorder(temp->right);
  }
} 
 
int depth(node *temp)
{
  if(temp == NULL) 
   return 0;
  return (max((depth(temp->left)),(depth(temp->right))) +1);  
}
 
};

// node* deleteNode(node* root, int key)
// {
// 	// base case
// 	if (root == NULL)
// 		return root;

// 	if (key < root->key)                                         // If the key to be deleted is smaller than the root's
//         root->left = deleteNode(root->left, key);	              //    key, then it lies in left subtree                                             
	                                                                
	                                                                   
// 	else if (key > root->key)
// 		root->right = deleteNode(root->right, key);    //If the key to be deleted is greater than the root's key, then it lies in right subtree

// 	// if key is same as root's key, then This is the node
// 	// to be deleted
// 	else {
// 		// node has no child
// 		if (root->left==NULL and root->right==NULL)
// 			return NULL;
	
// 		// node with only one child or no child
// 		else if (root->left == NULL) {
// 			node* temp = root->right;
// 			free(root);
// 			return temp;
// 		}
// 		else if (root->right == NULL) {
// 			node* temp = root->left;
// 			free(root);
// 			return temp;
// 		}

		// node with two children: Get the inorder successor
		// 
		
// 		node* temp = minValueNode(root->right);

// 		// Copy the inorder successor's content to this node
// 		root->key = temp->key;

// 		// Delete the inorder successor
// 		root->right = deleteNode(root->right, temp->key);
// 	}
// 	return root;
// }

int main()
{
    Btree obj;
    int ch;
    
    do{
    cout<<"\n!---MENU---!";
    cout<<"\n1. Insert a node";
    cout<<"\n2. Calculate Depth of the Tree";
    cout<<"\n3. Minimum Value in the Tree";
    cout<<"\n4. Mirror Tree";
    cout<<"\n5. Search a Value";
    
    cout<<"\n\nEnter a choice: ";
    cin>>ch;
    
    switch(ch)
    {
        case 1:
            obj.create();
            obj.display();
            break;
            
        case 2:
            cout<<"\nDepth of the Tree is: "<<obj.depth(obj.root)-1;
            cout<<endl;
            break;
            
        case 3:
            obj.minValueNode(obj.root);
            break;
            
        case 4:
            obj.mirror(obj.root);
            cout<<"\nInorder Traversal after mirroring Tree: ";
            obj.inorder(obj.root);
            cout<<endl;
            break;
            
        case 5:
            int k;
            cout<<"\nEnter the key to be searched: ";
            cin>>k;
            int a;
            obj.search(obj.root,k);
            // if( a == 0)
            // {
            //     cout<<"\nKEY NOT FOUND"<<endl;
            // }
            // else
            // cout<<"\nKEY FOUND"<<endl;
            
    }
    
}while(ch!=6);

	return 0;
}












