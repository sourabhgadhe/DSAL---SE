// Represent a given graph using adjacency matrix/list to perform DFS and using adjacency
// list to perform BFS. Use the map of the area around the college as the graph. Identify the
// prominent land marks as nodes and perform DFS and BFS on that.

#include<bits/stdc++.h>
using namespace std;

int nodes;
vector <int> l[20];
int adj_mat[20][20];
int visited[20];     // for DFS
bool vis[20];       // for BFS
string places[20];

void DFS(int i)   // function for DFS traversal
{
    cout<<i<<" ";
    visited[i]=1;                   // marking current node as visited
    for (int j=0; j<nodes; j++)
    {
        if (adj_mat[i][j]==1 && !visited[j])
        {
            DFS(j);                    // recurrsive call for unvisited nodes
        }
    }
}

void BFS(int s)               // function for BFS traversal
{
    for(int i=0; i<nodes; i++)
    {
        vis[i]=0;
    }
    
    queue<int>q;         // initiating queue
    q.push(s);
    
    vis[s]=true;
    
    while (!q.empty())
    {
        int n = q.front();
        q.pop();
        
        cout<<n<<" ";
        
        vector<int> :: iterator it;
        
        for(it=l[n].begin(); it!=l[n].end(); it++)
        {
            if(!vis[*it])
            {
                vis[*it]=1;
                q.push(*it);
            }
        }
    }
}

void display_adj_matrix()       // function to display Adjacency matrix
{
     for(int a=0; a<nodes; a++)
    {
        for(int b=0; b<nodes; b++)
        {
            cout<<"("<<places[a]<<","<<places[b]<<") "<<adj_mat[a][b]<<" "; // displaying Adjacency matrix
        }
        cout<<endl;
    }
}

void display_adj_list()
{
    for(int i=0; i<nodes; i++)
    {
        cout<<"Node: "<<i<<" -> ";
        for(int nbr:l[i])
        {
            cout<<nbr<<" ";
        }
        cout<<endl;
    }
}

int main()
{
    cout<<"Enter the number of nodes: ";   // taking user input for nodes 
    cin>>nodes;
    
    
    cout<<"Enter the names of those nodes: "<<endl;
    for(int i=0; i<nodes; i++)
    {
        cout<<"Node "<<i+1<<": ";
        cin>>places[i];
      
    }
    cout<<"\nEntered nodes are...."<<endl;  // displaying entered nodes
    
    for(int j=0; j<nodes; j++)
    {
        cout<<places[j]<<"  ";
    }
    
    for(int i=0; i<(nodes); i++)
    {
        for(int j=0; j<nodes; j++)
        {
            char edge;
            cout<<"\nIs there any route from "<<places[i]<<" to "<<places[j]<<" (Enter: y/n) : ";
            cin>>edge;    
            
            if (edge=='y')
            {
                adj_mat[i][j]=1;      
                l[i].push_back(j);    // most imp remember
            }
            else if(edge=='n')
            {
                adj_mat[i][j]=0;
            }
            
        }
    }
    
    cout<<"\nThe Adjacency matrix is :"<<endl<<"\n";  
    display_adj_matrix();
  
    cout<<endl;
    
    
    cout<<"\nThe Adjacency list is :"<<endl<<"\n";  
    display_adj_list();
    
    int initial_node_DFS;
    cout<<endl;
    for (int a=0; a<nodes; a++)
    {
        cout<<"Node("<<a<<")"<<" : "<<places[a]<<endl; // displaying node values for each city
    }
    cout<<"\nFrom which node do you want to start DFS? (Enter integer value of a node -> 0,1...): ";
    
    cin>>initial_node_DFS;                              // asking for initial node for DFS traversal
    cout<<"\nDFS Traversal for given graph is: ";
    
    DFS(initial_node_DFS);                        // calling DFS function 
    
    int initial_node_BFS;
    
    cout<<"\n\nFrom which node do you want to start BFS? (Enter integer value of a node -> 0,1...): ";
    cin>>initial_node_BFS;                              // asking for initial node for BFS traversal
    cout<<"\nBFS Traversal for given graph is: ";
    
    BFS(initial_node_BFS);                    // calling BFS function
    
    return 0;
}







