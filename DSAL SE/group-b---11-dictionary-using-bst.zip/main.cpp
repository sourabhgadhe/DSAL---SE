/* A Dictionary stores keywords & its meanings. Provide facility for adding new keywords,
deleting keywords, updating values of any entry. Provide facility to display whole data
sorted in ascending/ Descending order. Also find how many maximum comparisons may
require for finding any keyword. Use Binary Search Tree for implementation. */

#include <bits/stdc++.h>
using namespace std;

struct node
{
  char k[20];
  char m[20];			// use char array only for strcmp and strcpy functions
  class node *left;
  class node *right;

};

class dict
{
public:
  node * root;
  
void create ()
{
  int ch;

  do
    {
      node *temp = new node();
      cout << "\nEnter Keyword: ";
      cin >> temp->k;
      cout << "\nEnter it's Meaning: ";
      cin >> temp->m;

      temp->left = temp->right = NULL;

      if (root == NULL)
	{
	  root = temp;
	}
      else
	{
	  insert (root, temp);
	}
      cout << "\nDo you want to add more (y=1/n=0): ";
      cin >> ch;
    }
    
  while (ch == 1);

}

void insert (node * root, node * temp)            // learn this 
{
  if (strcmp (temp->k, root->k) < 0)
    {
      if (root->left == NULL)
	    root->left = temp;
      else
	    insert (root->left, temp);
    }
  else
    {
      if (root->right == NULL)
	root->right = temp;
      else
	insert (root->right, temp);
    }

}

void disp (node * root)
{
  if (root != NULL)
    {
      disp (root->left);
      cout << "\n Keyword : " << root->k;
      cout << "\t Meaning : " << root->m;
      disp (root->right);
    }
}

int search (node * root, char k[20])
{
  int c = 0;
  while (root != NULL)
    {
      c++;
      if (strcmp (k, root->k) == 0)
	{
	  cout << "\nNo of Comparisons: " << c;
	  return 1;
	}
      if (strcmp (k, root->k) < 0) // if ascii val of left parameter(k) < rt. par.(root->k) then strcmp returns value less than 0
	    root = root->left;
      if (strcmp (k, root->k) > 0)
	    root = root->right;
    }

  return -1;
}

int update (node * root, char k[20])
{
  while (root != NULL)
    {
        if (strcmp (k, root->k) == 0)
	    {
	        cout << "\nEnter New Meaning of Keyword " << root->k <<" : ";
	        cin >> root->m;
	        return 1;
	    }
	    
        if (strcmp (k, root->k) < 0)
	        root = root->left;
        if (strcmp (k, root->k) > 0)
	        root = root->right;
    }
  return -1;
}

node *del (node * root, char k[20])
{
  node *temp;

  if (root == NULL)
    {
      cout << "\nElement Not Found";
      return root;
    }

  if (strcmp (k, root->k) < 0)
    {
      root->left = del (root->left, k);
      return root;
    }
  if (strcmp (k, root->k) > 0)
    {
      root->right = del (root->right, k);
      return root;
    }

  if (root->right == NULL && root->left == NULL)  //if node to be deleted is leaf node
    {
      temp = root;
      delete temp;
      return NULL;
    }
    
  if (root->right == NULL)  // if node to be deleted has no right child
    {
      temp = root;
      root = root->left;
      delete temp;
      return root;
    }
  else if (root->left == NULL)  // if node to be deleted has no left child
    {                                                                        
      temp = root;
      root = root->right;
      delete temp;
      return root;
    }

  temp = min (root->right);         // if node to be deleted is root node or the node has two childrens.....else condition
  strcpy (root->k, temp->k);
  root->right = del (root->right, temp->k);
  return root;

}

node *min (node * q)
{
  while (q->left != NULL)
    {
      q = q->left;
    }
  return q;
}

};

int main ()
{
  int ch;
  dict d;
  d.root = NULL;


  do
    {
      cout <<
	"\n\n!...Menu...!\n1.Create\n2.Display\n3.Search\n4.Update\n5.Delete\nEnter your choice: ";
      cin >> ch;

      switch (ch)
	{
	case 1:
	  d.create ();
	  break;
	case 2:
	  if (d.root == NULL)
	    {
	      cout << "\nNo any Keyword (Tree Empty !!)";
	    }
	  else
	    {
	      d.disp (d.root);
	    }
	  break;
	case 3:
	  if (d.root == NULL)
	    {
	      cout <<"\nDictionary is Empty. First add keywords then try again !!";
	    }
	  else
	    {

	      cout << "\nEnter Keyword which u want to search: ";
	      char k[20];
	      cin >> k;

	      if (d.search (d.root, k) == 1)
		cout << "\nKeyword Found !"<<endl;
	      else
		cout << "\nKeyword Not Found !";
	    }
	  break;
	case 4:
	  if (d.root == NULL)
	    {
	      cout <<"\nDictionary is Empty. First add keywords then try again ";
	    }
	  else
	    {
	      cout <<"\nEnter the Keyword for which meaning is to be updated: ";
	      char k[20];
	      cin >> k;
	      if (d.update (d.root, k) == 1)
		cout << "\nMeaning Updated !";
	      else
		cout << "\nKey Not Found !";
	    }
	  break;
	case 5:
	  if (d.root == NULL)
	    {
	      cout <<"\nDictionary is Empty. First add keywords then try again ";
	    }
	  else
	    {
	      cout << "\nEnter Keyword which u want to delete: ";
	      char k[20];
	      cin >> k;
	      if (d.root == NULL)
		{
		  cout << "\nNo any Keyword";
		}
	      else
		{
		  d.root = d.del (d.root, k);
		}
	    }
	}
    }
  while (ch <= 5);


  return 0;

}



